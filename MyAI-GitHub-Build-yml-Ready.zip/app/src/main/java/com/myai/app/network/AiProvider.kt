package com.myai.app.network

import kotlinx.coroutines.flow.Flow

data class ChatTurn(val role: String, val content: String)

sealed class StreamEvent {
    data class Delta(val textChunk: String) : StreamEvent()
    data object Done : StreamEvent()
    data class Error(val message: String, val isAuthError: Boolean = false) : StreamEvent()
}

/**
 * Abstraction over "which AI answers the chat". Swapping providers (Groq,
 * OpenAI-compatible, a private backend proxy, etc.) only requires a new
 * implementation of this interface — nothing else in the app changes.
 */
interface AiProvider {
    /** True once the user has configured the credentials this provider needs. */
    fun isConfigured(): Boolean

    /** Streams the assistant's reply for [history] (last message = latest user turn). */
    fun streamReply(history: List<ChatTurn>, modelId: String): Flow<StreamEvent>
}
