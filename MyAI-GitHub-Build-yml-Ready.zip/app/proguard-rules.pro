# Keep kotlinx.serialization models
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class com.myai.app.network.** {
    *** Companion;
}
-keep,includedescriptorclasses class com.myai.app.**$$serializer { *; }
-keepclassmembers class com.myai.app.** {
    *** Companion;
}
-keep class com.myai.app.network.** { *; }

# Room
-keep class * extends androidx.room.RoomDatabase
