This workflow is designed for a repository where the Android project may be inside a folder.

It automatically searches for settings.gradle.kts/settings.gradle, changes into that project directory,
installs Gradle 8.7, passes GEMINI_API_KEY as a Gradle property, and builds the debug APK.

Required GitHub Actions repository secret:
GEMINI_API_KEY

IMPORTANT SECURITY NOTE:
This Android project currently puts the Gemini API key into BuildConfig. A GitHub Secret protects
the key while it is stored in GitHub, but the final APK can potentially expose an embedded API key.
For real key protection, the app should call a backend and the Gemini key should remain server-side.
