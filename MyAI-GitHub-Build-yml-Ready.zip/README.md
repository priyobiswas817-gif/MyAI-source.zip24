# MyAI — Gemini Chat APK Source

এই project-এ Gemini API configuration প্রস্তুত করা আছে।

## API সেটআপ
- Local testing-এর জন্য `local.properties` ফাইলে `GEMINI_API_KEY` রাখা আছে।
- `local.properties` Git দ্বারা ignored, তাই এটি GitHub-এ commit করা উচিত নয়।
- GitHub Actions APK build-এর জন্য repository Settings → Secrets and variables → Actions → New repository secret-এ `GEMINI_API_KEY` নামে secret যোগ করুন। Workflow নিজে থেকেই সেটি Gradle-এ পাঠাবে।

## GitHub থেকে APK
1. ZIP extract করে সব project file GitHub repository-তে upload করুন।
2. `local.properties` upload/commit করবেন না (এটি `.gitignore`-এ আছে)।
3. GitHub repository → Settings → Secrets and variables → Actions → New repository secret।
4. Name: `GEMINI_API_KEY` এবং Value: আপনার Gemini API key।
5. Actions → **Build APK** → **Run workflow**।
6. Build শেষ হলে `MyAI-debug-apk` artifact থেকে APK নিন।

## Security
API key-কে password-এর মতো গোপন রাখুন। Google-এর বর্তমান guidance অনুযায়ী API key source control-এ রাখা বা production mobile app-এর client-side code-এ hard-code করা উচিত নয়; production-এর জন্য backend proxy/server-side secret ব্যবহার করা নিরাপদ।

এই ZIP-এর `local.properties`-এর key কেবল local build convenience-এর জন্য। GitHub-এ project publish করার আগে key-টি নতুন করে rotate করা এবং GitHub Secret ব্যবহার করা সবচেয়ে ভালো।
