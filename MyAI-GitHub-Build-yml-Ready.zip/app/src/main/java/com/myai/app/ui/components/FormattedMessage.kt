package com.myai.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private data class MessagePart(val isCode: Boolean, val language: String, val text: String)

private fun parseParts(raw: String): List<MessagePart> {
    val parts = mutableListOf<MessagePart>()
    val regex = Regex("```(\\w*)\\n([\\s\\S]*?)```")
    var lastIndex = 0
    for (match in regex.findAll(raw)) {
        if (match.range.first > lastIndex) {
            parts.add(MessagePart(false, "", raw.substring(lastIndex, match.range.first)))
        }
        val lang = match.groupValues[1]
        val code = match.groupValues[2].trimEnd('\n')
        parts.add(MessagePart(true, lang, code))
        lastIndex = match.range.last + 1
    }
    if (lastIndex < raw.length) {
        parts.add(MessagePart(false, "", raw.substring(lastIndex)))
    }
    if (parts.isEmpty()) parts.add(MessagePart(false, "", raw))
    return parts
}

/** Renders assistant/user text with fenced-code-block detection, monospace code, and a copy action per block. */
@Composable
fun FormattedMessage(text: String, onSurfaceColor: Color, modifier: Modifier = Modifier) {
    val clipboard: ClipboardManager = LocalClipboardManager.current
    val parts = parseParts(text)

    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        parts.forEach { part ->
            if (part.isCode) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1E1E28), RoundedCornerShape(10.dp))
                        .padding(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = part.language.ifBlank { "code" },
                            color = Color(0xFFAAAAAA),
                            fontSize = 12.sp
                        )
                        IconButton(
                            onClick = { clipboard.setText(AnnotatedString(part.text)) },
                            modifier = Modifier.padding(0.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.ContentCopy,
                                contentDescription = "Copy code",
                                tint = Color(0xFFCCCCCC)
                            )
                        }
                    }
                    Text(
                        text = part.text,
                        color = Color(0xFFE6E6E6),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp,
                        modifier = Modifier.horizontalScroll(rememberScrollState())
                    )
                }
            } else if (part.text.isNotBlank()) {
                Text(
                    text = part.text.trim('\n'),
                    color = onSurfaceColor,
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }
    }
}
