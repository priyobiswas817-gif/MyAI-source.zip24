package com.myai.app.repository

import com.myai.app.data.ChatDao
import com.myai.app.data.ChatMessageEntity
import com.myai.app.data.ChatSession
import com.myai.app.network.AiProvider
import com.myai.app.network.ChatTurn
import com.myai.app.network.StreamEvent
import kotlinx.coroutines.flow.Flow

class ChatRepository(
    private val dao: ChatDao,
    private val aiProvider: AiProvider
) {
    fun observeSessions(): Flow<List<ChatSession>> = dao.observeSessions()

    fun observeMessages(sessionId: Long): Flow<List<ChatMessageEntity>> = dao.observeMessages(sessionId)

    suspend fun createSession(title: String = "New Chat"): Long = dao.insertSession(ChatSession(title = title))

    suspend fun renameSession(sessionId: Long, title: String) = dao.renameSession(sessionId, title)

    suspend fun deleteSession(sessionId: Long) = dao.deleteSession(sessionId)

    suspend fun clearMessages(sessionId: Long) = dao.clearMessages(sessionId)

    suspend fun clearAllHistory() = dao.clearAllSessions()

    suspend fun addUserMessage(sessionId: Long, content: String): Long {
        dao.touchSession(sessionId)
        return dao.insertMessage(ChatMessageEntity(sessionId = sessionId, role = "user", content = content))
    }

    suspend fun addAssistantMessage(sessionId: Long, content: String, isError: Boolean = false): Long =
        dao.insertMessage(
            ChatMessageEntity(sessionId = sessionId, role = "assistant", content = content, isError = isError)
        )

    suspend fun updateMessageContent(message: ChatMessageEntity, newContent: String, isError: Boolean = false) {
        dao.updateMessage(message.copy(content = newContent, isError = isError))
    }

    suspend fun deleteMessage(message: ChatMessageEntity) = dao.deleteMessage(message)

    fun isProviderConfigured(): Boolean = aiProvider.isConfigured()

    /** Streams a reply for the given conversation turns from the configured AI provider. */
    fun streamAssistantReply(history: List<ChatTurn>, modelId: String): Flow<StreamEvent> =
        aiProvider.streamReply(history, modelId)

    suspend fun getHistoryOnce(sessionId: Long): List<ChatMessageEntity> = dao.getMessagesOnce(sessionId)
}
