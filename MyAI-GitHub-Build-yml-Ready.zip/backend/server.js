import express from "express";
const app=express();
app.use(express.json({limit:"64kb"}));
const API_KEY=process.env.GEMINI_API_KEY;
const MODEL=process.env.GEMINI_MODEL || "gemini-2.5-flash";

app.get("/health",(req,res)=>res.json({ok:true}));
app.post("/chat",async(req,res)=>{
  try{
    if(!API_KEY) return res.status(500).json({error:"Server API key is not configured."});
    const messages=Array.isArray(req.body?.messages)?req.body.messages:[];
    if(!messages.length) return res.status(400).json({error:"messages is required"});
    const contents=messages.slice(-20).map(m=>({
      role:m.role==="assistant"?"model":"user",
      parts:[{text:String(m.content||"")}]
    }));
    const url=`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent`;
    const r=await fetch(url,{
      method:"POST",
      headers:{"Content-Type":"application/json","x-goog-api-key":API_KEY},
      body:JSON.stringify({
        systemInstruction:{parts:[{text:"You are a helpful AI assistant. If the user writes Bengali, answer in Bengali. Be accurate and concise."}]},
        contents
      })
    });
    const data=await r.json();
    if(!r.ok) return res.status(r.status).json({error:data?.error?.message||"Gemini request failed"});
    const text=data?.candidates?.[0]?.content?.parts?.map(p=>p.text||"").join("")||"No response.";
    res.json({text});
  }catch(e){res.status(500).json({error:"Backend request failed"});}
});
const port=process.env.PORT||8080;
app.listen(port,()=>console.log("MyAI proxy listening on "+port));
